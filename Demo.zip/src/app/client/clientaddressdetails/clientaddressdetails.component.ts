import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientaddressdetails',
  templateUrl: './clientaddressdetails.component.html',
  styleUrls: ['./clientaddressdetails.component.css']
})
export class ClientaddressdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
