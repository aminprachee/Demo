import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientaddressdetailsComponent } from './clientaddressdetails.component';

describe('ClientaddressdetailsComponent', () => {
  let component: ClientaddressdetailsComponent;
  let fixture: ComponentFixture<ClientaddressdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientaddressdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientaddressdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
