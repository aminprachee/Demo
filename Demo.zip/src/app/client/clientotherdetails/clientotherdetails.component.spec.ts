import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientotherdetailsComponent } from './clientotherdetails.component';

describe('ClientotherdetailsComponent', () => {
  let component: ClientotherdetailsComponent;
  let fixture: ComponentFixture<ClientotherdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientotherdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientotherdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
