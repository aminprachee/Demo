import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientotherdetails',
  templateUrl: './clientotherdetails.component.html',
  styleUrls: ['./clientotherdetails.component.css']
})
export class ClientotherdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
