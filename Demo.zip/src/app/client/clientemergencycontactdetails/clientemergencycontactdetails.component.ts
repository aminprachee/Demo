import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientemergencycontactdetails',
  templateUrl: './clientemergencycontactdetails.component.html',
  styleUrls: ['./clientemergencycontactdetails.component.css']
})
export class ClientemergencycontactdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
