import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientemergencycontactdetailsComponent } from './clientemergencycontactdetails.component';

describe('ClientemergencycontactdetailsComponent', () => {
  let component: ClientemergencycontactdetailsComponent;
  let fixture: ComponentFixture<ClientemergencycontactdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientemergencycontactdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientemergencycontactdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
