import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientcontactdetailsComponent } from './clientcontactdetails.component';

describe('ClientcontactdetailsComponent', () => {
  let component: ClientcontactdetailsComponent;
  let fixture: ComponentFixture<ClientcontactdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientcontactdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientcontactdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
