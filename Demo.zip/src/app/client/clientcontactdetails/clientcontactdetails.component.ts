import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientcontactdetails',
  templateUrl: './clientcontactdetails.component.html',
  styleUrls: ['./clientcontactdetails.component.css']
})
export class ClientcontactdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
