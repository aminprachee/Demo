import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { FlexLayoutModule } from '@angular/flex-layout'
import { FormsModule, ReactiveFormsModule } from '@angular/Forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule} from './material.module';
import { LoginComponent } from './auth/login/login.component';
import { ClientComponent } from './client/client.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './navigation/header/header.component';
import { SidenavListComponent } from './navigation/sidenav-list/sidenav-list.component';
import { ClientdetailsComponent } from './client/clientdetails/clientdetails.component';
import { ClientcontactdetailsComponent } from './client/clientcontactdetails/clientcontactdetails.component';
import { ClientaddressdetailsComponent } from './client/clientaddressdetails/clientaddressdetails.component';
import { ClientemergencycontactdetailsComponent } from './client/clientemergencycontactdetails/clientemergencycontactdetails.component';
import { ClientotherdetailsComponent } from './client/clientotherdetails/clientotherdetails.component'

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ClientComponent,
    DashboardComponent,
    HeaderComponent,
    SidenavListComponent,
    ClientdetailsComponent,
    ClientcontactdetailsComponent,
    ClientaddressdetailsComponent,
    ClientemergencycontactdetailsComponent,
    ClientotherdetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
