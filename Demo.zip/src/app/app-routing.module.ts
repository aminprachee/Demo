import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { ClientComponent } from './client/client.component';
import { DashboardComponent } from './dashboard/dashboard.component';


const routes: Routes = [
    { path: '' , component: LoginComponent },
    {
      path: "dashboard",
      component: DashboardComponent
    },
    { path: 'Client', 
      component: ClientComponent
    }
];

//NgModule is a decorator.
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
