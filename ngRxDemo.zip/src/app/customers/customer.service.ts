import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { Observable } from "rxjs";

import { Customer } from "./customer.model";

@Injectable({
  providedIn: "root"
})
export class CustomerService {
  private customersUrl = "https://localhost:44349/api/customers";

  constructor(private http: HttpClient) {}

  getCustomers(): Observable<Customer[]> {
      return this.http.get<Customer[]>(`${this.customersUrl}/getCustomers/`);
  }

  getCustomerById(id: number): Observable<Customer> {
    return this.http.get<Customer>(`${this.customersUrl}/getCustomerById/${id}`);
  }

  createCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(`${this.customersUrl}/createCustomer`, customer);
  }

  updateCustomer(customer: Customer): Observable<Customer> {
    return this.http.patch<Customer>(`${this.customersUrl}/updateCustomer/`,customer);
  }

  deleteCustomer(id: number) {
    return this.http.delete(`${this.customersUrl}/deleteCustomer/${id}`);
  }
}
