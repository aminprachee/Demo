// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyAfT1nQ08qhB_BCig24XI_rNGIVMZLmOE8",
    authDomain: "ng-fitness-tracker-bd345.firebaseapp.com",
    projectId: "ng-fitness-tracker-bd345",
    storageBucket: "ng-fitness-tracker-bd345.appspot.com",
    messagingSenderId: "516513956789",
    appId: "1:516513956789:web:a0de92e1b1375ae7234ffc",
    measurementId: "G-1F5HJ2X4LV"
  },
  firebase: {
    apiKey: 'AIzaSyAfT1nQ08qhB_BCig24XI_rNGIVMZLmOE8',
    authDomain: 'ng-fitness-tracker-bd345.firebaseapp.com',
    databaseURL: 'https://ng-fitness-tracker.firebaseio.com',
    projectId: 'ng-fitness-tracker-bd345',
    storageBucket: 'ng-fitness-tracker-bd345.appspot.com',
    messagingSenderId: '516513956789',
    appId: "1:516513956789:web:a0de92e1b1375ae7234ffc",
    measurementId: "G-1F5HJ2X4LV"
  }
};
